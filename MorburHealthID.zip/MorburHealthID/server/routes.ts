import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertUserSchema,
  insertHealthProfileSchema,
  insertAllergySchema,
  insertMedicationSchema,
  insertEmergencyContactSchema,
  updateUserSchema,
  updateHealthProfileSchema,
  updateMedicationSchema,
  updateEmergencyContactSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  app.get("/api/users/unique/:uniqueId", async (req, res) => {
    try {
      const user = await storage.getUserByUniqueId(req.params.uniqueId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const validated = insertUserSchema.parse(req.body);
      const user = await storage.createUser(validated);
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const validated = updateUserSchema.parse(req.body);
      const user = await storage.updateUser(req.params.id, validated);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ error: "Failed to update user" });
    }
  });

  // Health Profile routes
  app.get("/api/health-profiles/:userId", async (req, res) => {
    try {
      const profile = await storage.getHealthProfile(req.params.userId);
      if (!profile) {
        return res.status(404).json({ error: "Health profile not found" });
      }
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch health profile" });
    }
  });

  app.post("/api/health-profiles", async (req, res) => {
    try {
      const validated = insertHealthProfileSchema.parse(req.body);
      const profile = await storage.createHealthProfile(validated);
      res.status(201).json(profile);
    } catch (error) {
      res.status(400).json({ error: "Invalid health profile data" });
    }
  });

  app.patch("/api/health-profiles/:userId", async (req, res) => {
    try {
      const validated = updateHealthProfileSchema.parse(req.body);
      const profile = await storage.updateHealthProfile(req.params.userId, validated);
      if (!profile) {
        return res.status(404).json({ error: "Health profile not found" });
      }
      res.json(profile);
    } catch (error) {
      res.status(400).json({ error: "Failed to update health profile" });
    }
  });

  // Allergy routes
  app.get("/api/allergies/:userId", async (req, res) => {
    try {
      const allergies = await storage.getAllergies(req.params.userId);
      res.json(allergies);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch allergies" });
    }
  });

  app.post("/api/allergies", async (req, res) => {
    try {
      const validated = insertAllergySchema.parse(req.body);
      const allergy = await storage.createAllergy(validated);
      res.status(201).json(allergy);
    } catch (error) {
      res.status(400).json({ error: "Invalid allergy data" });
    }
  });

  app.delete("/api/allergies/:id", async (req, res) => {
    try {
      await storage.deleteAllergy(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete allergy" });
    }
  });

  // Medication routes
  app.get("/api/medications/:userId", async (req, res) => {
    try {
      const medications = await storage.getMedications(req.params.userId);
      res.json(medications);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch medications" });
    }
  });

  app.post("/api/medications", async (req, res) => {
    try {
      const validated = insertMedicationSchema.parse(req.body);
      const medication = await storage.createMedication(validated);
      res.status(201).json(medication);
    } catch (error) {
      res.status(400).json({ error: "Invalid medication data" });
    }
  });

  app.patch("/api/medications/:id", async (req, res) => {
    try {
      const validated = updateMedicationSchema.parse(req.body);
      const medication = await storage.updateMedication(req.params.id, validated);
      if (!medication) {
        return res.status(404).json({ error: "Medication not found" });
      }
      res.json(medication);
    } catch (error) {
      res.status(400).json({ error: "Failed to update medication" });
    }
  });

  app.delete("/api/medications/:id", async (req, res) => {
    try {
      await storage.deleteMedication(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete medication" });
    }
  });

  // Emergency Contact routes
  app.get("/api/emergency-contacts/:userId", async (req, res) => {
    try {
      const contacts = await storage.getEmergencyContacts(req.params.userId);
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch emergency contacts" });
    }
  });

  app.post("/api/emergency-contacts", async (req, res) => {
    try {
      const validated = insertEmergencyContactSchema.parse(req.body);
      const contact = await storage.createEmergencyContact(validated);
      res.status(201).json(contact);
    } catch (error) {
      res.status(400).json({ error: "Invalid emergency contact data" });
    }
  });

  app.patch("/api/emergency-contacts/:id", async (req, res) => {
    try {
      const validated = updateEmergencyContactSchema.parse(req.body);
      const contact = await storage.updateEmergencyContact(req.params.id, validated);
      if (!contact) {
        return res.status(404).json({ error: "Emergency contact not found" });
      }
      res.json(contact);
    } catch (error) {
      res.status(400).json({ error: "Failed to update emergency contact" });
    }
  });

  app.delete("/api/emergency-contacts/:id", async (req, res) => {
    try {
      await storage.deleteEmergencyContact(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete emergency contact" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

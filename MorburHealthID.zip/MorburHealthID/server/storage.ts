import { db } from "./db";
import { eq, and } from "drizzle-orm";
import {
  users,
  healthProfiles,
  allergies,
  medications,
  emergencyContacts,
  type User,
  type InsertUser,
  type HealthProfile,
  type InsertHealthProfile,
  type Allergy,
  type InsertAllergy,
  type Medication,
  type InsertMedication,
  type EmergencyContact,
  type InsertEmergencyContact,
} from "@shared/schema";
import { randomUUID } from "crypto";
import bcrypt from "bcrypt";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUniqueId(uniqueId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<User>): Promise<User | undefined>;

  // Health Profile operations
  getHealthProfile(userId: string): Promise<HealthProfile | undefined>;
  createHealthProfile(profile: InsertHealthProfile): Promise<HealthProfile>;
  updateHealthProfile(userId: string, data: Partial<HealthProfile>): Promise<HealthProfile | undefined>;

  // Allergy operations
  getAllergies(userId: string): Promise<Allergy[]>;
  createAllergy(allergy: InsertAllergy): Promise<Allergy>;
  deleteAllergy(id: string): Promise<void>;

  // Medication operations
  getMedications(userId: string): Promise<Medication[]>;
  createMedication(medication: InsertMedication): Promise<Medication>;
  updateMedication(id: string, data: Partial<Medication>): Promise<Medication | undefined>;
  deleteMedication(id: string): Promise<void>;

  // Emergency Contact operations
  getEmergencyContacts(userId: string): Promise<EmergencyContact[]>;
  createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact>;
  updateEmergencyContact(id: string, data: Partial<EmergencyContact>): Promise<EmergencyContact | undefined>;
  deleteEmergencyContact(id: string): Promise<void>;
}

export class DbStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async getUserByUniqueId(uniqueId: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.uniqueId, uniqueId)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const uniqueId = `MBR-${new Date().getFullYear()}-${randomUUID().substring(0, 8).toUpperCase()}`;
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const result = await db
      .insert(users)
      .values({ ...insertUser, password: hashedPassword, uniqueId })
      .returning();
    return result[0];
  }

  async updateUser(id: string, data: Partial<User>): Promise<User | undefined> {
    const updateData = { ...data, updatedAt: new Date() };
    if (data.password) {
      updateData.password = await bcrypt.hash(data.password, 10);
    }
    const result = await db
      .update(users)
      .set(updateData)
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  // Health Profile operations
  async getHealthProfile(userId: string): Promise<HealthProfile | undefined> {
    const result = await db
      .select()
      .from(healthProfiles)
      .where(eq(healthProfiles.userId, userId))
      .limit(1);
    return result[0];
  }

  async createHealthProfile(profile: InsertHealthProfile): Promise<HealthProfile> {
    const result = await db.insert(healthProfiles).values(profile).returning();
    return result[0];
  }

  async updateHealthProfile(
    userId: string,
    data: Partial<HealthProfile>
  ): Promise<HealthProfile | undefined> {
    const result = await db
      .update(healthProfiles)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(healthProfiles.userId, userId))
      .returning();
    return result[0];
  }

  // Allergy operations
  async getAllergies(userId: string): Promise<Allergy[]> {
    return await db.select().from(allergies).where(eq(allergies.userId, userId));
  }

  async createAllergy(allergy: InsertAllergy): Promise<Allergy> {
    const result = await db.insert(allergies).values(allergy).returning();
    return result[0];
  }

  async deleteAllergy(id: string): Promise<void> {
    await db.delete(allergies).where(eq(allergies.id, id));
  }

  // Medication operations
  async getMedications(userId: string): Promise<Medication[]> {
    return await db.select().from(medications).where(eq(medications.userId, userId));
  }

  async createMedication(medication: InsertMedication): Promise<Medication> {
    const result = await db.insert(medications).values(medication).returning();
    return result[0];
  }

  async updateMedication(id: string, data: Partial<Medication>): Promise<Medication | undefined> {
    const result = await db
      .update(medications)
      .set(data)
      .where(eq(medications.id, id))
      .returning();
    return result[0];
  }

  async deleteMedication(id: string): Promise<void> {
    await db.delete(medications).where(eq(medications.id, id));
  }

  // Emergency Contact operations
  async getEmergencyContacts(userId: string): Promise<EmergencyContact[]> {
    return await db
      .select()
      .from(emergencyContacts)
      .where(eq(emergencyContacts.userId, userId));
  }

  async createEmergencyContact(contact: InsertEmergencyContact): Promise<EmergencyContact> {
    const result = await db.insert(emergencyContacts).values(contact).returning();
    return result[0];
  }

  async updateEmergencyContact(
    id: string,
    data: Partial<EmergencyContact>
  ): Promise<EmergencyContact | undefined> {
    const result = await db
      .update(emergencyContacts)
      .set(data)
      .where(eq(emergencyContacts.id, id))
      .returning();
    return result[0];
  }

  async deleteEmergencyContact(id: string): Promise<void> {
    await db.delete(emergencyContacts).where(eq(emergencyContacts.id, id));
  }
}

export const storage = new DbStorage();

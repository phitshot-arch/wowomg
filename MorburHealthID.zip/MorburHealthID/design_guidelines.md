# Morbur NFC Sağlık Kimlik Sistemi - Design Guidelines

## Design Approach

**Selected Approach**: Design System-Based (Material Design 3) with healthcare-sector adaptations

**Rationale**: Life-critical application requiring immediate comprehension, accessibility for elderly users, and trust establishment in medical context. Material Design 3 provides established patterns for data-dense interfaces while maintaining clarity.

**Key Design Principles**:
1. **Rapid Comprehension**: Critical information must be scannable in 2-3 seconds
2. **Medical Credibility**: Professional aesthetic that builds trust with healthcare providers
3. **Accessibility-First**: Large touch targets, high contrast, readable fonts for elderly users
4. **Mobile-Native**: NFC functionality requires smartphone-optimized layouts

## Core Design Elements

### A. Typography

**Primary Font Family**: Inter (via Google Fonts CDN)
- **Hero/Headings**: 600 weight, 32-48px mobile / 48-72px desktop
- **Section Headers**: 600 weight, 24-32px
- **Body Text**: 400 weight, 16-18px (larger than typical for readability)
- **Medical Data Labels**: 500 weight, 14px uppercase with letter-spacing
- **Critical Info (Blood Type, Allergies)**: 700 weight, 20-24px

**Secondary Font Family**: Roboto Mono (for unique ID display)
- **User IDs**: 500 weight, 16-18px with generous letter-spacing

### B. Layout System

**Spacing Primitives**: Tailwind units of 3, 4, 6, 8, 12, 16
- **Card padding**: p-6 mobile, p-8 desktop
- **Section spacing**: py-12 mobile, py-16 desktop
- **Component gaps**: gap-4 for related items, gap-8 for distinct sections
- **Grid gaps**: gap-6 for cards, gap-3 for form fields

**Container Strategy**:
- Marketing pages: max-w-7xl centered
- Application dashboard: max-w-6xl
- Profile view (emergency access): max-w-2xl for focus
- Form layouts: max-w-xl for optimal completion

**Grid Patterns**:
- Emergency info cards: Single column mobile, 2-column tablet/desktop
- Medical history timeline: Single column throughout
- Marketing features: grid-cols-1 md:grid-cols-3
- Dashboard stats: grid-cols-2 md:grid-cols-4

### C. Component Library

**Navigation**:
- Fixed top navigation with Morbur logo
- Hamburger menu mobile, horizontal desktop
- Profile avatar with dropdown for authenticated users
- Emergency access button (prominent, always visible)

**Cards**:
- Elevated cards with shadow-md for content grouping
- Border-l-4 accent for critical medical information
- Rounded corners (rounded-lg) for modern feel
- Hover state: shadow-lg transition for interactive cards

**Buttons**:
- Primary CTA: Large (h-12 md:h-14), full-width mobile
- Secondary actions: Outlined style, h-10
- Icon buttons: w-10 h-10 with centered icons
- Emergency button: Distinctive styling, always accessible

**Forms**:
- Generous input height (h-12) for touch accessibility
- Floating labels or clear top labels
- Inline validation with icons (checkmark/error)
- Multi-step forms with progress indicator for registration

**Data Display**:
- **Emergency Card**: Large text, icon badges for critical info (blood type icon, allergy warning icon)
- **Timeline**: Vertical timeline for medical history
- **Stat Cards**: Large numbers with descriptive labels
- **Badge System**: Status indicators (active/inactive, verified/unverified)

**Icons**: Heroicons (via CDN)
- Medical icons: heart, shield, document, user, phone
- Action icons: pencil, trash, eye, download
- Consistent 24px size, stroke-2

**Modals/Overlays**:
- Full-screen mobile, centered desktop
- NFC scanning animation modal
- Confirmation dialogs for critical actions
- Profile preview lightbox

### D. Animations

**Use Sparingly**:
- NFC scanning: Pulse animation on scan icon (2s duration)
- Success states: Subtle checkmark fade-in
- Page transitions: None (instant for emergency context)
- Form validation: Shake animation on error (300ms)

**NO animations for**:
- Emergency profile display (instant render)
- Medical data updates
- Navigation changes

## Page-Specific Guidelines

### Landing Page (Marketing)

**Structure** (6 sections):
1. **Hero**: Full-screen height with image background (person with NFC card at hospital), overlaid content centered, primary CTA "Ücretsiz Deneyin", secondary CTA "Nasıl Çalışır?"
2. **Problem Statement**: 2-column layout (illustration + text), highlighting emergency access challenges
3. **Features Grid**: 3-column cards showing offline access, privacy, affordability
4. **How It Works**: 3-step timeline with icons (Register → NFC Setup → Emergency Access)
5. **Trust Signals**: Logo grid of partner hospitals/insurance companies, testimonial cards (2-column)
6. **Pricing**: Comparison table (Morbur vs competitors), emphasized 300₺ price point
7. **Final CTA**: Full-width section with blurred background image, form capture

**Multi-Column Usage**:
- Features: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Testimonials: grid-cols-1 md:grid-cols-2
- Stats (below hero): grid-cols-2 md:grid-cols-4
- Partner logos: grid-cols-3 md:grid-cols-6

### Dashboard (Authenticated)

**Structure**:
- Top: Stats row (4 cards - Profile completion, Emergency contacts, Medical records, Last updated)
- Main: 2-column layout (Profile summary + Quick actions)
- Below: Tabbed interface (Sağlık Bilgileri, Acil Kişiler, Geçmiş, Ayarlar)
- Sidebar: Recent activity feed (desktop only)

### Emergency Profile View

**Structure**:
- **Critical Info First**: Blood type, allergies, chronic conditions in large cards
- **Emergency Contacts**: List with call buttons
- **Medical History**: Collapsible accordion, latest first
- **Action Bar**: Call 112, Download PDF, Share buttons

**Layout**: Single column, max-w-2xl, large text throughout, high contrast

## Images

**Hero Image**: Professional photo of person holding NFC card near smartphone in medical setting (hospital corridor or examination room background), warm lighting, Turkish demographic representation

**Feature Section Images**: 
- Illustration of NFC scanning process
- Photo of elderly person using smartphone with ease
- Medical professional accessing patient information quickly

**Placement**: Hero background (with overlay), feature section alternating left/right, testimonial avatars

**Treatment**: Subtle overlay gradient on hero for text readability, rounded corners on feature images (rounded-xl)
import Navbar from "@/components/Navbar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Heart,
  Users,
  FileText,
  Clock,
  Edit,
  Eye,
  Download,
  AlertCircle,
  CheckCircle2,
  Smartphone
} from "lucide-react";
import { useState } from "react";

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("overview");

  const profileCompletion = 85;
  const uniqueId = "MBR-2024-8A3F";

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-semibold text-foreground mb-2">
                Kontrol Paneli
              </h1>
              <p className="text-muted-foreground">
                Sağlık profilinizi yönetin ve acil durum bilgilerinizi güncelleyin
              </p>
            </div>
            <Button data-testid="button-view-emergency-profile">
              <Eye className="w-4 h-4 mr-2" />
              Acil Profili Görüntüle
            </Button>
          </div>

          <Card className="p-6 mb-6">
            <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
              <Avatar className="w-20 h-20">
                <AvatarFallback className="bg-primary/10 text-primary text-2xl font-semibold">
                  AY
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="text-xl font-semibold text-foreground">
                    Ahmet Yılmaz
                  </h2>
                  <Badge variant="secondary" className="bg-accent text-accent-foreground">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    Aktif
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                  <Smartphone className="w-4 h-4" />
                  <span className="font-mono font-medium">{uniqueId}</span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Profil Tamamlanma</span>
                    <span className="font-medium text-foreground">{profileCompletion}%</span>
                  </div>
                  <Progress value={profileCompletion} className="h-2" />
                </div>
              </div>

              <Button variant="outline" data-testid="button-edit-profile">
                <Edit className="w-4 h-4 mr-2" />
                Düzenle
              </Button>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="p-4 hover-elevate">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                <Heart className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-semibold text-foreground">4</div>
                <div className="text-xs text-muted-foreground">Sağlık Kayıtları</div>
              </div>
            </div>
          </Card>

          <Card className="p-4 hover-elevate">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-md bg-accent/20 flex items-center justify-center">
                <Users className="w-5 h-5 text-accent-foreground" />
              </div>
              <div>
                <div className="text-2xl font-semibold text-foreground">2</div>
                <div className="text-xs text-muted-foreground">Acil Kişiler</div>
              </div>
            </div>
          </Card>

          <Card className="p-4 hover-elevate">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                <FileText className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="text-2xl font-semibold text-foreground">12</div>
                <div className="text-xs text-muted-foreground">Toplam Kayıt</div>
              </div>
            </div>
          </Card>

          <Card className="p-4 hover-elevate">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-md bg-muted flex items-center justify-center">
                <Clock className="w-5 h-5 text-muted-foreground" />
              </div>
              <div>
                <div className="text-sm font-medium text-foreground">2 saat önce</div>
                <div className="text-xs text-muted-foreground">Son Güncelleme</div>
              </div>
            </div>
          </Card>
        </div>

        <div className="mb-6">
          <div className="flex gap-2 border-b overflow-x-auto">
            <button
              className={`px-4 py-2 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === "overview"
                  ? "text-primary border-b-2 border-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              onClick={() => setActiveTab("overview")}
              data-testid="tab-overview"
            >
              Genel Bakış
            </button>
            <button
              className={`px-4 py-2 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === "health"
                  ? "text-primary border-b-2 border-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              onClick={() => setActiveTab("health")}
              data-testid="tab-health"
            >
              Sağlık Bilgileri
            </button>
            <button
              className={`px-4 py-2 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === "emergency"
                  ? "text-primary border-b-2 border-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              onClick={() => setActiveTab("emergency")}
              data-testid="tab-emergency"
            >
              Acil Kişiler
            </button>
            <button
              className={`px-4 py-2 text-sm font-medium whitespace-nowrap transition-colors ${
                activeTab === "settings"
                  ? "text-primary border-b-2 border-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
              onClick={() => setActiveTab("settings")}
              data-testid="tab-settings"
            >
              Ayarlar
            </button>
          </div>
        </div>

        {activeTab === "overview" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Kritik Sağlık Bilgileri
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b">
                  <span className="text-sm text-muted-foreground">Kan Grubu</span>
                  <Badge variant="secondary" className="font-mono">A Rh+</Badge>
                </div>
                <div className="flex justify-between items-start py-2 border-b">
                  <span className="text-sm text-muted-foreground">Alerjiler</span>
                  <div className="flex flex-wrap gap-1 justify-end">
                    <Badge variant="destructive" className="text-xs">Penisilin</Badge>
                    <Badge variant="destructive" className="text-xs">Fıstık</Badge>
                  </div>
                </div>
                <div className="flex justify-between items-start py-2 border-b">
                  <span className="text-sm text-muted-foreground">Kronik Hastalıklar</span>
                  <div className="text-right">
                    <div className="text-sm font-medium text-foreground">Diyabet Tip 2</div>
                  </div>
                </div>
                <div className="flex justify-between items-start py-2">
                  <span className="text-sm text-muted-foreground">Sürekli İlaçlar</span>
                  <div className="text-right">
                    <div className="text-sm font-medium text-foreground">Metformin 500mg</div>
                  </div>
                </div>
              </div>
              <Button variant="outline" className="w-full mt-4" data-testid="button-edit-health">
                <Edit className="w-4 h-4 mr-2" />
                Sağlık Bilgilerini Düzenle
              </Button>
            </Card>

            <Card className="p-6">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Acil Durumda Ulaşılacak Kişiler
              </h3>
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 rounded-md bg-muted/30">
                  <Avatar>
                    <AvatarFallback className="bg-primary/10 text-primary">
                      EY
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="font-medium text-sm text-foreground">Emine Yılmaz</div>
                    <div className="text-xs text-muted-foreground">Eş • 0532 123 45 67</div>
                  </div>
                  <Badge variant="secondary">Birincil</Badge>
                </div>

                <div className="flex items-center gap-3 p-3 rounded-md bg-muted/30">
                  <Avatar>
                    <AvatarFallback className="bg-accent/20 text-accent-foreground">
                      MK
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="font-medium text-sm text-foreground">Mehmet Kaya</div>
                    <div className="text-xs text-muted-foreground">Kardeş • 0533 987 65 43</div>
                  </div>
                  <Badge variant="outline">İkincil</Badge>
                </div>
              </div>
              <Button variant="outline" className="w-full mt-4" data-testid="button-add-contact">
                <Users className="w-4 h-4 mr-2" />
                Yeni Kişi Ekle
              </Button>
            </Card>

            <Card className="p-6 lg:col-span-2">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground">
                  Son Aktiviteler
                </h3>
                <Button variant="ghost" size="sm">
                  Tümünü Gör
                </Button>
              </div>
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 rounded-md hover-elevate">
                  <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="w-4 h-4 text-accent-foreground" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-foreground">Profil güncellendi</div>
                    <div className="text-xs text-muted-foreground">Kan grubu bilgisi eklendi</div>
                  </div>
                  <div className="text-xs text-muted-foreground whitespace-nowrap">2 saat önce</div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-md hover-elevate">
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Download className="w-4 h-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-foreground">NFC kartı etkinleştirildi</div>
                    <div className="text-xs text-muted-foreground">Unique ID: {uniqueId}</div>
                  </div>
                  <div className="text-xs text-muted-foreground whitespace-nowrap">1 gün önce</div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-md hover-elevate">
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                    <AlertCircle className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-foreground">Acil kişi eklendi</div>
                    <div className="text-xs text-muted-foreground">Emine Yılmaz birincil kişi olarak ayarlandı</div>
                  </div>
                  <div className="text-xs text-muted-foreground whitespace-nowrap">3 gün önce</div>
                </div>
              </div>
            </Card>
          </div>
        )}

        {activeTab === "health" && (
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-6">
              Sağlık Bilgilerim
            </h3>
            <div className="text-muted-foreground text-center py-12">
              Sağlık bilgileri formu burada olacak (geliştirilecek)
            </div>
          </Card>
        )}

        {activeTab === "emergency" && (
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-6">
              Acil Durumda Ulaşılacak Kişiler
            </h3>
            <div className="text-muted-foreground text-center py-12">
              Acil kişiler yönetim formu burada olacak (geliştirilecek)
            </div>
          </Card>
        )}

        {activeTab === "settings" && (
          <Card className="p-6">
            <h3 className="text-lg font-semibold text-foreground mb-6">
              Ayarlar
            </h3>
            <div className="text-muted-foreground text-center py-12">
              Gizlilik ve güvenlik ayarları burada olacak (geliştirilecek)
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

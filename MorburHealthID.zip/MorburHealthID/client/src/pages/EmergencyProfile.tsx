import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  AlertCircle,
  Droplet,
  Phone,
  Pill,
  Activity,
  Download,
  Share2,
  Calendar
} from "lucide-react";

export default function EmergencyProfile() {
  const uniqueId = "MBR-2024-8A3F";

  return (
    <div className="min-h-screen bg-background">
      <div className="bg-destructive/10 border-b-4 border-destructive py-4">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <AlertCircle className="w-6 h-6 text-destructive" />
            <h1 className="text-xl font-semibold text-foreground">
              ACİL DURUM SAĞLIK PROFİLİ
            </h1>
          </div>
          <p className="text-sm text-muted-foreground">
            Bu bilgiler acil müdahale için kritik öneme sahiptir
          </p>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8 space-y-6">
        <Card className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <Avatar className="w-16 h-16">
              <AvatarFallback className="bg-primary/10 text-primary text-xl font-semibold">
                AY
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h2 className="text-2xl font-semibold text-foreground">
                Ahmet Yılmaz
              </h2>
              <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                <Calendar className="w-4 h-4" />
                <span>45 yaşında • Erkek</span>
              </div>
              <div className="font-mono text-xs text-muted-foreground mt-1">
                {uniqueId}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <div className="border-l-4 border-destructive bg-destructive/5 p-4 rounded-md">
              <div className="flex items-center gap-2 mb-2">
                <Droplet className="w-5 h-5 text-destructive" />
                <span className="text-xs font-medium uppercase text-muted-foreground tracking-wide">
                  Kan Grubu
                </span>
              </div>
              <div className="text-3xl font-bold text-foreground">
                A Rh+
              </div>
            </div>

            <div className="border-l-4 border-destructive bg-destructive/5 p-4 rounded-md">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="w-5 h-5 text-destructive" />
                <span className="text-xs font-medium uppercase text-muted-foreground tracking-wide">
                  Alerjiler
                </span>
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge variant="destructive" className="text-sm font-semibold">
                  Penisilin
                </Badge>
                <Badge variant="destructive" className="text-sm font-semibold">
                  Fıstık
                </Badge>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold text-foreground">
              Kronik Hastalıklar
            </h3>
          </div>
          <div className="space-y-3">
            <div className="p-3 bg-muted/30 rounded-md">
              <div className="font-medium text-foreground">Diyabet Tip 2</div>
              <div className="text-sm text-muted-foreground mt-1">
                Tanı: 2018 • Düzenli kontrol altında
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <Pill className="w-5 h-5 text-primary" />
            <h3 className="text-lg font-semibold text-foreground">
              Sürekli Kullanılan İlaçlar
            </h3>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between items-center p-3 bg-muted/30 rounded-md">
              <div>
                <div className="font-medium text-foreground">Metformin</div>
                <div className="text-xs text-muted-foreground">500mg • Günde 2 kez</div>
              </div>
            </div>
            <div className="flex justify-between items-center p-3 bg-muted/30 rounded-md">
              <div>
                <div className="font-medium text-foreground">Aspirin</div>
                <div className="text-xs text-muted-foreground">100mg • Günde 1 kez</div>
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-accent/5 border-accent">
          <div className="flex items-center gap-2 mb-4">
            <Phone className="w-5 h-5 text-accent-foreground" />
            <h3 className="text-lg font-semibold text-foreground">
              Acil Durumda Aranacak Kişiler
            </h3>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-background rounded-md">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback className="bg-primary/10 text-primary">
                    EY
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-semibold text-foreground">Emine Yılmaz</div>
                  <div className="text-sm text-muted-foreground">Eş</div>
                </div>
              </div>
              <Button size="sm" data-testid="button-call-primary">
                <Phone className="w-4 h-4 mr-2" />
                0532 123 45 67
              </Button>
            </div>

            <div className="flex items-center justify-between p-3 bg-background rounded-md">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback className="bg-accent/20 text-accent-foreground">
                    MK
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-semibold text-foreground">Mehmet Kaya</div>
                  <div className="text-sm text-muted-foreground">Kardeş</div>
                </div>
              </div>
              <Button size="sm" variant="outline" data-testid="button-call-secondary">
                <Phone className="w-4 h-4 mr-2" />
                0533 987 65 43
              </Button>
            </div>
          </div>
        </Card>

        <div className="flex flex-col sm:flex-row gap-3">
          <Button className="flex-1" size="lg" data-testid="button-call-112">
            <Phone className="w-5 h-5 mr-2" />
            112 Acil Servis
          </Button>
          <Button variant="outline" className="flex-1" size="lg" data-testid="button-download-pdf">
            <Download className="w-5 h-5 mr-2" />
            PDF İndir
          </Button>
          <Button variant="outline" size="lg" data-testid="button-share">
            <Share2 className="w-5 h-5" />
          </Button>
        </div>

        <Card className="p-4 bg-muted/30">
          <p className="text-xs text-muted-foreground text-center">
            Son güncelleme: 2 saat önce • Bu bilgiler kullanıcı tarafından sağlanmıştır
          </p>
        </Card>
      </div>
    </div>
  );
}

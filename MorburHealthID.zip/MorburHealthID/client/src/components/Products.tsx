import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, ShoppingCart } from "lucide-react";
import wristbandImage from "@assets/generated_images/NFC_health_wristband_product_e1f17f06.png";
import necklaceImage from "@assets/generated_images/NFC_health_pendant_necklace_d4560c94.png";
import walletCardImage from "@assets/generated_images/NFC_wallet_health_card_ac88f2d2.png";

const products = [
  {
    name: "NFC Sağlık Kartı",
    category: "Cüzdan Kartı",
    price: "300₺",
    image: walletCardImage,
    description: "Cüzdanınızda taşıyabileceğiniz standart kart boyutunda NFC sağlık kimliği.",
    features: [
      "Kredi kartı boyutunda",
      "Su geçirmez tasarım",
      "5 yıl garanti",
      "Cüzdana kolayca sığar"
    ],
    badge: "Popüler",
    badgeVariant: "default" as const
  },
  {
    name: "NFC Sağlık Bilekliği",
    category: "Bileklik",
    price: "450₺",
    image: wristbandImage,
    description: "Spor ve günlük kullanım için rahat, su geçirmez sağlık bilekliği.",
    features: [
      "Ayarlanabilir boyut",
      "Yüzme/duş yapılabilir",
      "Hipoalerjenik malzeme",
      "Hafif ve konforlu"
    ],
    badge: "Sporculara Özel",
    badgeVariant: "secondary" as const
  },
  {
    name: "NFC Sağlık Kolyesi",
    category: "Kolye",
    price: "550₺",
    image: necklaceImage,
    description: "Zarif tasarımlı, paslanmaz çelik NFC sağlık kolyesi. Günlük kullanım için ideal.",
    features: [
      "Paslanmaz çelik zincir",
      "Şık ve zarif tasarım",
      "Ayarlanabilir zincir uzunluğu",
      "Kadın ve erkek modelleri"
    ],
    badge: "Premium",
    badgeVariant: "secondary" as const
  }
];

export default function Products() {
  return (
    <section id="urunler" className="py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-4">
            Ürünlerimiz
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Yaşam tarzınıza uygun NFC sağlık kimlik ürününüzü seçin
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {products.map((product, index) => (
            <Card key={index} className="overflow-hidden flex flex-col" data-testid={`card-product-${index}`}>
              <div className="relative">
                {product.badge && (
                  <div className="absolute top-4 right-4 z-10">
                    <Badge variant={product.badgeVariant}>
                      {product.badge}
                    </Badge>
                  </div>
                )}
                <div className="bg-muted/30 p-8 flex items-center justify-center min-h-[280px]">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-auto max-w-[240px] object-contain"
                  />
                </div>
              </div>

              <div className="p-6 flex-1 flex flex-col">
                <div className="mb-2">
                  <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                    {product.category}
                  </span>
                </div>
                
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  {product.name}
                </h3>
                
                <p className="text-sm text-muted-foreground mb-4 flex-1">
                  {product.description}
                </p>

                <ul className="space-y-2 mb-6">
                  {product.features.map((feature, fIndex) => (
                    <li key={fIndex} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="border-t pt-4 mt-auto">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="text-2xl font-semibold text-foreground">
                        {product.price}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        Tek seferlik ödeme
                      </div>
                    </div>
                  </div>

                  <Button className="w-full" data-testid={`button-order-${index}`}>
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Sipariş Ver
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <Card className="p-8 bg-primary/5 border-primary/20">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="text-3xl font-semibold text-foreground mb-2">
                Ücretsiz
              </div>
              <div className="text-sm text-muted-foreground">
                Tüm Türkiye'ye kargo
              </div>
            </div>
            <div>
              <div className="text-3xl font-semibold text-foreground mb-2">
                5 Yıl
              </div>
              <div className="text-sm text-muted-foreground">
                Garantili kullanım
              </div>
            </div>
            <div>
              <div className="text-3xl font-semibold text-foreground mb-2">
                7/24
              </div>
              <div className="text-sm text-muted-foreground">
                Teknik destek
              </div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}

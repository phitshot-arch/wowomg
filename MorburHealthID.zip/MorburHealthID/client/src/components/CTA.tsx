import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

export default function CTA() {
  return (
    <section className="py-16 md:py-24 bg-primary/5">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-4">
          Hayat Kurtaran Teknoloji Bir Dokunuş Uzağınızda
        </h2>
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
          Acil durumlarda sağlık bilgilerinize anında erişim sağlayın. Bugün Morbur ailesine katılın ve güvende olun.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/register">
            <Button size="lg" className="w-full sm:w-auto text-base h-12" data-testid="button-cta-primary">
              Ücretsiz Deneyin
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
          <Link href="/dashboard">
            <Button size="lg" variant="outline" className="w-full sm:w-auto text-base h-12" data-testid="button-cta-secondary">
              Profilimi Görüntüle
            </Button>
          </Link>
        </div>

        <p className="text-sm text-muted-foreground mt-6">
          İlk 1000 kullanıcıya özel %20 indirim
        </p>
      </div>
    </section>
  );
}

import { Link } from "wouter";
import { Shield, Mail, Phone, MapPin } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-muted/30 border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <Link href="/" className="flex items-center gap-2 mb-4">
              <Shield className="w-6 h-6 text-primary" />
              <span className="text-lg font-semibold">Morbur</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              NFC tabanlı acil durum sağlık kimlik sistemi. Hayat kurtaran teknoloji.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-4">Ürün</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/#nasil-calisir" className="text-muted-foreground hover:text-foreground transition-colors">
                  Nasıl Çalışır?
                </Link>
              </li>
              <li>
                <Link href="/#ozellikler" className="text-muted-foreground hover:text-foreground transition-colors">
                  Özellikler
                </Link>
              </li>
              <li>
                <Link href="/#fiyatlandirma" className="text-muted-foreground hover:text-foreground transition-colors">
                  Fiyatlandırma
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="text-muted-foreground hover:text-foreground transition-colors">
                  Giriş Yap
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-4">Şirket</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-foreground transition-colors">
                  Hakkımızda
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-muted-foreground hover:text-foreground transition-colors">
                  Gizlilik Politikası
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-muted-foreground hover:text-foreground transition-colors">
                  Kullanım Şartları
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-foreground transition-colors">
                  İletişim
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-foreground mb-4">İletişim</h3>
            <ul className="space-y-3 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <Mail className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>destek@morbur.com</span>
              </li>
              <li className="flex items-start gap-2">
                <Phone className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>0850 123 45 67</span>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <span>İstanbul, Türkiye</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t pt-8">
          <p className="text-center text-sm text-muted-foreground">
            © 2024 Morbur. Tüm hakları saklıdır.
          </p>
        </div>
      </div>
    </footer>
  );
}

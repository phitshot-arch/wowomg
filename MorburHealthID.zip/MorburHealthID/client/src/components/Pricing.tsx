import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, X } from "lucide-react";
import { Link } from "wouter";

const plans = [
  {
    name: "MedicAlert",
    price: "$100-300",
    period: "Yıllık",
    description: "Global marka",
    features: [
      { text: "Sınırlı offline erişim", available: true },
      { text: "NFC desteği", available: false },
      { text: "Türkiye odaklı", available: false },
      { text: "Uygun fiyat", available: false }
    ],
    highlighted: false
  },
  {
    name: "Morbur",
    price: "300₺",
    period: "Tek Seferlik",
    description: "En iyi değer",
    features: [
      { text: "Tam offline erişim", available: true },
      { text: "NFC teknolojisi", available: true },
      { text: "Türkiye için optimize", available: true },
      { text: "10x daha uygun", available: true }
    ],
    highlighted: true
  },
  {
    name: "EvdeAcil",
    price: "7.000₺",
    period: "Kurulum",
    description: "Panik butonu",
    features: [
      { text: "Online bağlantı gerekli", available: false },
      { text: "NFC desteği", available: false },
      { text: "Sınırlı entegrasyon", available: true },
      { text: "Yüksek maliyet", available: false }
    ],
    highlighted: false
  }
];

export default function Pricing() {
  return (
    <section id="fiyatlandirma" className="py-16 md:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-4">
            Rekabetçi Fiyatlandırma
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Rakiplerimizden 10 kat daha uygun, aynı kalitede hizmet
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`p-6 relative ${
                plan.highlighted ? 'border-primary border-2' : ''
              }`}
              data-testid={`card-pricing-${index}`}
            >
              {plan.highlighted && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full">
                    ÖNERİLEN
                  </span>
                </div>
              )}

              <div className="text-center mb-6">
                <h3 className="text-xl font-semibold text-foreground mb-1">
                  {plan.name}
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {plan.description}
                </p>
                <div className="mb-1">
                  <span className="text-3xl font-semibold text-foreground">
                    {plan.price}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  {plan.period}
                </p>
              </div>

              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-start gap-2">
                    {feature.available ? (
                      <Check className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
                    ) : (
                      <X className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                    )}
                    <span className={`text-sm ${
                      feature.available ? 'text-foreground' : 'text-muted-foreground line-through'
                    }`}>
                      {feature.text}
                    </span>
                  </li>
                ))}
              </ul>

              {plan.highlighted ? (
                <Link href="/register">
                  <Button className="w-full" data-testid="button-pricing-cta">
                    Hemen Başla
                  </Button>
                </Link>
              ) : (
                <Button variant="outline" className="w-full" disabled>
                  Diğer Seçenek
                </Button>
              )}
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

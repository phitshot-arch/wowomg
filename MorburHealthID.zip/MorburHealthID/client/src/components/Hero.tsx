import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Play } from "lucide-react";
import heroImage from "@assets/generated_images/NFC_card_hospital_scan_hero_48376aeb.png";

export default function Hero() {
  return (
    <section className="relative min-h-[600px] md:min-h-[700px] flex items-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/85 to-background/60" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-24">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-semibold text-foreground mb-6 leading-tight">
            Acil Durumlarda
            <span className="text-primary block mt-2">Hayat Kurtaran</span>
            Sağlık Kimliğiniz
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
            NFC teknolojisi ile kan grubunuz, alerjileriniz ve tıbbi geçmişiniz acil durumlarda 2 saniyede erişilebilir. İnternet bağlantısı gerekmez.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/register">
              <Button size="lg" className="w-full sm:w-auto text-base h-12" data-testid="button-hero-cta">
                Ücretsiz Deneyin
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Button
              size="lg"
              variant="outline"
              className="w-full sm:w-auto text-base h-12 bg-background/60 backdrop-blur"
              data-testid="button-hero-video"
            >
              <Play className="mr-2 w-5 h-5" />
              Nasıl Çalışır?
            </Button>
          </div>

          <div className="mt-12 flex items-center gap-8 text-sm text-muted-foreground">
            <div>
              <div className="text-2xl font-semibold text-foreground">24M+</div>
              <div>Potansiyel Kullanıcı</div>
            </div>
            <div>
              <div className="text-2xl font-semibold text-foreground">2 Saniye</div>
              <div>Hızlı Erişim</div>
            </div>
            <div>
              <div className="text-2xl font-semibold text-foreground">300₺</div>
              <div>Uygun Fiyat</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

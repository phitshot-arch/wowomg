import Products from '../Products'

export default function ProductsExample() {
  return <Products />
}

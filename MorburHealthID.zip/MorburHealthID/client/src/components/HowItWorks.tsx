import { Card } from "@/components/ui/card";
import { UserPlus, CreditCard, Shield } from "lucide-react";
import nfcDiagram from "@assets/generated_images/NFC_scanning_process_diagram_f2a19da1.png";

const steps = [
  {
    icon: UserPlus,
    step: "1",
    title: "Kayıt Olun",
    description: "Sağlık bilgilerinizi güvenli bir şekilde sisteme girin. Kan grubu, alerjiler ve kronik hastalıklarınızı ekleyin."
  },
  {
    icon: CreditCard,
    step: "2",
    title: "NFC Kartınızı Alın",
    description: "Benzersiz NFC sağlık kartınız veya bileziğiniz hazırlanır ve adresinize gönderilir."
  },
  {
    icon: Shield,
    step: "3",
    title: "Güvende Olun",
    description: "Kartınızı yanınızda taşıyın. Acil durumlarda herhangi bir telefon ile taratarak bilgilerinize erişilebilir."
  }
];

export default function HowItWorks() {
  return (
    <section id="nasil-calisir" className="py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-4">
            Nasıl Çalışır?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Üç basit adımda hayat kurtaran sağlık kimliğinizi aktifleştirin
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="space-y-6">
            {steps.map((step, index) => (
              <div key={index} className="flex gap-4" data-testid={`step-${index}`}>
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-md bg-primary text-primary-foreground flex items-center justify-center font-semibold text-lg">
                    {step.step}
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <step.icon className="w-5 h-5 text-primary" />
                    <h3 className="text-lg font-semibold text-foreground">
                      {step.title}
                    </h3>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="relative">
            <Card className="p-6 overflow-hidden">
              <img
                src={nfcDiagram}
                alt="NFC Tarama Süreci"
                className="w-full h-auto rounded-md"
              />
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}

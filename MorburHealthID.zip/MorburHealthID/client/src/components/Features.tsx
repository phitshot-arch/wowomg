import { Card } from "@/components/ui/card";
import { Wifi, Lock, Zap, Heart, DollarSign, Globe } from "lucide-react";

const features = [
  {
    icon: Wifi,
    title: "Çevrimdışı Erişim",
    description: "İnternet bağlantısı olmadan bile acil durumlarda tüm sağlık bilgilerinize anında erişim sağlayın."
  },
  {
    icon: Lock,
    title: "Güvenli & Şifreli",
    description: "Verileriniz cihazda şifreli olarak saklanır. Gizliliğiniz tamamen sizin kontrolünüzde."
  },
  {
    icon: Zap,
    title: "2 Saniyede Erişim",
    description: "NFC kartınızı telefona okutun, acil durum bilgileriniz anında ekranda. Hızlı ve kolay."
  },
  {
    icon: Heart,
    title: "Hayat Kurtarıcı",
    description: "Bilinç kaybında doğru kan grubu, alerjiler ve ilaçlarınız sağlık personeline otomatik iletilir."
  },
  {
    icon: DollarSign,
    title: "Uygun Fiyat",
    description: "Sadece 300₺ ile rakiplerinden 10 kat daha uygun. Herkes için erişilebilir sağlık güvenliği."
  },
  {
    icon: Globe,
    title: "Evrensel Uyumluluk",
    description: "Tüm NFC özellikli telefonlarla çalışır. %99 cihaz uyumluluğu ile her yerde kullanılabilir."
  }
];

export default function Features() {
  return (
    <section id="ozellikler" className="py-16 md:py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-4">
            Neden Morbur?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Sağlık güvenliğiniz için ihtiyacınız olan her şey, modern teknoloji ile buluştu
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="p-6 hover-elevate" data-testid={`card-feature-${index}`}>
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                <feature.icon className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-card-foreground mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

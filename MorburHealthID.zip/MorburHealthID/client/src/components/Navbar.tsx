import { Link } from "wouter";
import { Menu, X, User, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center gap-2 hover-elevate active-elevate-2 rounded-md px-2 py-1 -ml-2" data-testid="link-logo">
            <Shield className="w-8 h-8 text-primary" />
            <span className="text-xl font-semibold text-foreground">Morbur</span>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            <Link href="/#nasil-calisir" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-how-it-works">
              Nasıl Çalışır?
            </Link>
            <Link href="/#ozellikler" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-features">
              Özellikler
            </Link>
            <Link href="/#urunler" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-products">
              Ürünler
            </Link>
            <Link href="/#fiyatlandirma" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="link-pricing">
              Fiyatlandırma
            </Link>
            <Link href="/dashboard">
              <Button variant="ghost" size="sm" data-testid="button-dashboard">
                <User className="w-4 h-4 mr-2" />
                Giriş Yap
              </Button>
            </Link>
            <Link href="/register">
              <Button size="sm" data-testid="button-register">
                Ücretsiz Dene
              </Button>
            </Link>
          </div>

          <button
            className="md:hidden p-2 hover-elevate active-elevate-2 rounded-md"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden border-t bg-background">
          <div className="px-4 py-4 space-y-3">
            <Link href="/#nasil-calisir" className="block py-2 text-sm font-medium text-muted-foreground" data-testid="link-mobile-how-it-works">
              Nasıl Çalışır?
            </Link>
            <Link href="/#ozellikler" className="block py-2 text-sm font-medium text-muted-foreground" data-testid="link-mobile-features">
              Özellikler
            </Link>
            <Link href="/#urunler" className="block py-2 text-sm font-medium text-muted-foreground" data-testid="link-mobile-products">
              Ürünler
            </Link>
            <Link href="/#fiyatlandirma" className="block py-2 text-sm font-medium text-muted-foreground" data-testid="link-mobile-pricing">
              Fiyatlandırma
            </Link>
            <div className="pt-3 space-y-2">
              <Link href="/dashboard">
                <Button variant="ghost" className="w-full justify-start" data-testid="button-mobile-dashboard">
                  <User className="w-4 h-4 mr-2" />
                  Giriş Yap
                </Button>
              </Link>
              <Link href="/register">
                <Button className="w-full" data-testid="button-mobile-register">
                  Ücretsiz Dene
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}

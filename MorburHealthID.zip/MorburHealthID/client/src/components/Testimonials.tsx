import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Star } from "lucide-react";
import elderlyImage from "@assets/generated_images/Elderly_person_using_smartphone_fddaf6ce.png";
import medicalImage from "@assets/generated_images/Medical_professional_emergency_access_6f7d428c.png";

const testimonials = [
  {
    name: "Mehmet Yılmaz",
    role: "Diyabet Hastası, 58",
    content: "Morbur sayesinde artık güvenle seyahat edebiliyorum. Şeker hastalığım ve alerjilerim her zaman yanımda. Acil durumlarda doktorlara hemen gösterebiliyorum.",
    rating: 5,
    avatar: "MY"
  },
  {
    name: "Dr. Ayşe Demir",
    role: "Acil Tıp Uzmanı",
    content: "Acil serviste hastanın tıbbi geçmişine hızlı erişim hayat kurtarıyor. Morbur sistemi 2 saniyede tüm kritik bilgileri sunuyor. Kesinlikle öneriyorum.",
    rating: 5,
    avatar: "AD"
  },
  {
    name: "Zeynep Kaya",
    role: "Anne, 42",
    content: "Çocuklarım için Morbur kartı aldım. Okulda veya spor aktivitelerinde bir sorun olursa, öğretmenler hemen bilgilere erişebiliyor. Çok daha rahatım.",
    rating: 5,
    avatar: "ZK"
  }
];

export default function Testimonials() {
  return (
    <section className="py-16 md:py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-4">
            Kullanıcılarımız Ne Diyor?
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Binlerce kişi Morbur ile güvende
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="p-6" data-testid={`card-testimonial-${index}`}>
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                ))}
              </div>
              
              <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                "{testimonial.content}"
              </p>

              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback className="bg-primary/10 text-primary font-medium">
                    {testimonial.avatar}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium text-foreground text-sm">
                    {testimonial.name}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {testimonial.role}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="overflow-hidden">
            <img
              src={elderlyImage}
              alt="Yaşlı kullanıcılarımız"
              className="w-full h-64 object-cover"
            />
          </Card>
          <Card className="overflow-hidden">
            <img
              src={medicalImage}
              alt="Sağlık profesyonelleri"
              className="w-full h-64 object-cover"
            />
          </Card>
        </div>
      </div>
    </section>
  );
}
